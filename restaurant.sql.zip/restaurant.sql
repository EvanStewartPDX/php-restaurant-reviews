--
-- Database: `restaurant`
--
CREATE DATABASE IF NOT EXISTS `restaurant` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `restaurant`;

-- --------------------------------------------------------

--
-- Table structure for table `cuisine`
--

CREATE TABLE `cuisine` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `type` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cuisine`
--

INSERT INTO `cuisine` (`id`, `type`) VALUES
(1, 'he'),
(2, 'THai Food'),
(3, 'Mexican'),
(4, 'Mexican'),
(5, 'Italian'),
(6, 'Italian'),
(7, 'Italian'),
(8, 'Italian'),
(9, 'dada');

-- --------------------------------------------------------

--
-- Table structure for table `restaurants`
--

CREATE TABLE `restaurants` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `cuisine_id` int(11) DEFAULT NULL,
  `neighborhood` varchar(255) DEFAULT NULL,
  `must_eats` varchar(255) DEFAULT NULL,
  `price_range` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `restaurants`
--

INSERT INTO `restaurants` (`id`, `name`, `cuisine_id`, `neighborhood`, `must_eats`, `price_range`) VALUES
(1, 'iouiouo', 2, 'uiouo', 'uiouopuiopu', 'iopuopi'),
(2, 'pok pok ', 2, 'SE', 'wings', '88980'),
(3, 'jlkjklj', 2, 'kljljlkjlk', 'jkjljl', 'jkljljl'),
(4, '87897879', 2, '7987979', '87879', '789798'),
(5, '87897879', 2, '7987979', '87879', '789798'),
(6, '87897879', 2, '7987979', '87879', '789798'),
(7, '87897879', 2, '7987979', '87879', '789798'),
(8, '87897879', 2, '7987979', '87879', '789798'),
(9, '98798798', 2, '798798', '798798', '7987987'),
(10, '9809890', 8, '8908908', '09890808', '089890'),
(11, 'hjkhjk', 9, 'hkhlk', 'jhkhl', 'khkj'),
(12, 'hjkhjkhjklhk', 9, 'ljhjklhkljh', 'jlkhkljhkl', 'hlkhjklkl'),
(13, 'hjkhjkhjklhk', 9, 'ljhjklhkljh', 'jlkhkljhkl', 'hlkhjklkl'),
(14, 'hjkhkjl', 8, 'hkljhjklh', 'kljhjklh', 'jklhjkl'),
(15, 'hkjhjklhlkj', 1, 'hjkhklhlkjhjklhjklh', 'kjlhjkhklh', 'lljhkj'),
(16, 'hkjhjklhlkj', 1, 'hjkhklhlkjhjklhjklh', 'kjlhjkhklh', 'lljhkj'),
(17, 'hkjhjkh', 1, 'jkhklh', 'kjhklhk', 'jlhklh'),
(18, 'hkjhjkh', 1, 'jkhklh', 'kjhklhk', 'jlhklh'),
(19, 'hkjhjkh', 1, 'jkhklh', 'kjhklhk', 'jlhklh'),
(20, '098', 1, '90809', '8097', '907097'),
(21, '098', 1, '90809', '8097', '907097'),
(22, '098', 1, '90809', '8097', '907097'),
(23, '098', 1, '90809', '8097', '907097');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cuisine`
--
ALTER TABLE `cuisine`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `restaurants`
--
ALTER TABLE `restaurants`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cuisine`
--
ALTER TABLE `cuisine`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `restaurants`
--
ALTER TABLE `restaurants`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
