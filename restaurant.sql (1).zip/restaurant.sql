--
-- Database: `restaurant`
--
CREATE DATABASE IF NOT EXISTS `restaurant` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `restaurant`;

-- --------------------------------------------------------

--
-- Table structure for table `cuisine`
--

CREATE TABLE `cuisine` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `type` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cuisine`
--

INSERT INTO `cuisine` (`id`, `type`) VALUES
(1, 'he'),
(2, 'THai Food'),
(3, 'Mexican'),
(4, 'Mexican'),
(5, 'Italian'),
(6, 'Italian'),
(7, 'Italian'),
(8, 'Italian'),
(9, 'dada'),
(10, 'afafaf'),
(11, 'zzzz'),
(12, 'zzzz'),
(13, 'laotian'),
(14, 'Martian'),
(15, ''),
(16, ''),
(17, 'Garbage'),
(18, ''),
(19, ''),
(20, ''),
(21, ''),
(22, ''),
(23, ''),
(24, ''),
(25, ''),
(26, ''),
(27, ''),
(28, '');

-- --------------------------------------------------------

--
-- Table structure for table `restaurants`
--

CREATE TABLE `restaurants` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `cuisine_id` int(11) DEFAULT NULL,
  `neighborhood` varchar(255) DEFAULT NULL,
  `must_eats` varchar(255) DEFAULT NULL,
  `price_range` varchar(255) DEFAULT NULL,
  `rating` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `restaurants`
--

INSERT INTO `restaurants` (`id`, `name`, `cuisine_id`, `neighborhood`, `must_eats`, `price_range`, `rating`) VALUES
(1, 'iouiouo', 2, 'uiouo', 'uiouopuiopu', 'iopuopi', 7),
(2, 'pok pok ', 2, 'SE', 'wings', '88980', NULL),
(3, 'jlkjklj', 2, 'kljljlkjlk', 'jkjljl', 'jkljljl', NULL),
(4, '87897879', 2, '7987979', '87879', '789798', NULL),
(5, '87897879', 2, '7987979', '87879', '789798', NULL),
(6, '87897879', 2, '7987979', '87879', '789798', NULL),
(7, '87897879', 2, '7987979', '87879', '789798', NULL),
(8, '87897879', 2, '7987979', '87879', '789798', NULL),
(9, '98798798', 2, '798798', '798798', '7987987', NULL),
(10, '9809890', 8, '8908908', '09890808', '089890', NULL),
(11, 'hjkhjk', 9, 'hkhlk', 'jhkhl', 'khkj', NULL),
(12, 'hjkhjkhjklhk', 9, 'ljhjklhkljh', 'jlkhkljhkl', 'hlkhjklkl', NULL),
(13, 'hjkhjkhjklhk', 9, 'ljhjklhkljh', 'jlkhkljhkl', 'hlkhjklkl', NULL),
(14, 'hjkhkjl', 8, 'hkljhjklh', 'kljhjklh', 'jklhjkl', NULL),
(15, 'hkjhjklhlkj', 1, 'hjkhklhlkjhjklhjklh', 'kjlhjkhklh', 'lljhkj', NULL),
(16, 'hkjhjklhlkj', 1, 'hjkhklhlkjhjklhjklh', 'kjlhjkhklh', 'lljhkj', NULL),
(17, 'hkjhjkh', 1, 'jkhklh', 'kjhklhk', 'jlhklh', NULL),
(18, 'hkjhjkh', 1, 'jkhklh', 'kjhklhk', 'jlhklh', NULL),
(19, 'hkjhjkh', 1, 'jkhklh', 'kjhklhk', 'jlhklh', NULL),
(20, '098', 1, '90809', '8097', '907097', NULL),
(21, '098', 1, '90809', '8097', '907097', NULL),
(22, '098', 1, '90809', '8097', '907097', NULL),
(23, '098', 1, '90809', '8097', '907097', NULL),
(24, 'hjkh', 3, 'kljhljhlkj', 'hjklh', 'kljhkjlhklj', NULL),
(25, 'jkklhl', 3, 'jhjhjkhjkh', 'lkjhjklklhjh', 'kljhklj', NULL),
(26, 'pok pok ', 8, 'nion', 'nion', '$$$', NULL),
(27, 'jkljkljl;j', 3, 'jl;jlk;j', 'l;kjl;kjlk;jlk;', 'jlkjl;k', 0),
(28, 'jkljkljl;j', 3, 'jl;jlk;j', 'l;kjl;kjlk;jlk;', 'jlkjl;k', 1),
(29, 'jkljkljl;j', 3, 'jl;jlk;j', 'l;kjl;kjlk;jlk;', 'jlkjl;k', 2),
(30, 'jkljkljl;j', 3, 'jl;jlk;j', 'l;kjl;kjlk;jlk;', 'jlkjl;k', 3),
(31, 'jkljkljl;j', 3, 'jl;jlk;j', 'l;kjl;kjlk;jlk;', 'jlkjl;k', 4),
(32, 'jkljkljl;j', 3, 'jl;jlk;j', 'l;kjl;kjlk;jlk;', 'jlkjl;k', 5),
(33, 'jkljkljl;j', 3, 'jl;jlk;j', 'l;kjl;kjlk;jlk;', 'jlkjl;k', 6),
(34, 'jkljkljl;j', 3, 'jl;jlk;j', 'l;kjl;kjlk;jlk;', 'jlkjl;k', 7),
(35, 'jkljkljl;j', 3, 'jl;jlk;j', 'l;kjl;kjlk;jlk;', 'jlkjl;k', 8),
(36, 'jkljkljl;j', 3, 'jl;jlk;j', 'l;kjl;kjlk;jlk;', 'jlkjl;k', 9),
(37, 'jkljkljl;j', 3, 'jl;jlk;j', 'l;kjl;kjlk;jlk;', 'jlkjl;k', 10),
(38, 'jkljkljl;j', 3, 'jl;jlk;j', 'l;kjl;kjlk;jlk;', 'jlkjl;k', 11),
(39, 'jkljkljl;j', 3, 'jl;jlk;j', 'l;kjl;kjlk;jlk;', 'jlkjl;k', 12),
(40, 'jkljkljl;j', 3, 'jl;jlk;j', 'l;kjl;kjlk;jlk;', 'jlkjl;k', 13),
(41, 'jkljkljl;j', 3, 'jl;jlk;j', 'l;kjl;kjlk;jlk;', 'jlkjl;k', 14),
(42, 'jkljkljl;j', 3, 'jl;jlk;j', 'l;kjl;kjlk;jlk;', 'jlkjl;k', 15),
(43, 'jkljkljl;j', 3, 'jl;jlk;j', 'l;kjl;kjlk;jlk;', 'jlkjl;k', 15),
(44, 'jkljkljl;j', 3, 'jl;jlk;j', 'l;kjl;kjlk;jlk;', 'jlkjl;k', 16),
(45, 'jkljkljl;j', 3, 'jl;jlk;j', 'l;kjl;kjlk;jlk;', 'jlkjl;k', 17),
(46, 'jkljkljl;j', 3, 'jl;jlk;j', 'l;kjl;kjlk;jlk;', 'jlkjl;k', 18),
(47, 'jkljkljl;j', 3, 'jl;jlk;j', 'l;kjl;kjlk;jlk;', 'jlkjl;k', 19),
(48, 'jkljkljl;j', 3, 'jl;jlk;j', 'l;kjl;kjlk;jlk;', 'jlkjl;k', 20),
(49, 'jkljkljl;j', 3, 'jl;jlk;j', 'l;kjl;kjlk;jlk;', 'jlkjl;k', 21),
(50, 'jkljkljl;j', 3, 'jl;jlk;j', 'l;kjl;kjlk;jlk;', 'jlkjl;k', 22),
(51, 'jkljkljl;j', 3, 'jl;jlk;j', 'l;kjl;kjlk;jlk;', 'jlkjl;k', 23),
(52, 'jkljkljl;j', 3, 'jl;jlk;j', 'l;kjl;kjlk;jlk;', 'jlkjl;k', 24),
(53, 'jkljkljl;j', 3, 'jl;jlk;j', 'l;kjl;kjlk;jlk;', 'jlkjl;k', 25),
(54, 'jkljkljl;j', 3, 'jl;jlk;j', 'l;kjl;kjlk;jlk;', 'jlkjl;k', 26),
(55, 'jkljkljl;j', 3, 'jl;jlk;j', 'l;kjl;kjlk;jlk;', 'jlkjl;k', 27),
(56, 'jkljkljl;j', 3, 'jl;jlk;j', 'l;kjl;kjlk;jlk;', 'jlkjl;k', 28),
(57, 'jkljkljl;j', 3, 'jl;jlk;j', 'l;kjl;kjlk;jlk;', 'jlkjl;k', 29),
(58, 'jkljkljl;j', 3, 'jl;jlk;j', 'l;kjl;kjlk;jlk;', 'jlkjl;k', 30),
(59, 'jkljkljl;j', 3, 'jl;jlk;j', 'l;kjl;kjlk;jlk;', 'jlkjl;k', 31),
(60, 'jkljkljl;j', 3, 'jl;jlk;j', 'l;kjl;kjlk;jlk;', 'jlkjl;k', 32),
(61, 'jkljkljl;j', 3, 'jl;jlk;j', 'l;kjl;kjlk;jlk;', 'jlkjl;k', 33),
(62, 'jkljkljl;j', 3, 'jl;jlk;j', 'l;kjl;kjlk;jlk;', 'jlkjl;k', 34),
(63, 'jkljkljl;j', 3, 'jl;jlk;j', 'l;kjl;kjlk;jlk;', 'jlkjl;k', 35),
(64, 'jkljkljl;j', 3, 'jl;jlk;j', 'l;kjl;kjlk;jlk;', 'jlkjl;k', 35),
(65, 'jkljkljl;j', 3, 'jl;jlk;j', 'l;kjl;kjlk;jlk;', 'jlkjl;k', 35),
(66, 'hjkhjkhjklhk', 9, 'ljhjklhkljh', 'jlkhkljhkl', 'hlkhjklkl', 1),
(67, 'hjkhjkhjklhk', 9, 'ljhjklhkljh', 'jlkhkljhkl', 'hlkhjklkl', 2),
(68, 'fafa', 11, '', '', '', 0),
(69, 'jkljkljl;j', 3, 'jl;jlk;j', 'l;kjl;kjlk;jlk;', 'jlkjl;k', 36),
(70, 'jkljkljl;j', 3, 'jl;jlk;j', 'l;kjl;kjlk;jlk;', 'jlkjl;k', 37),
(71, 'jkljkljl;j', 3, 'jl;jlk;j', 'l;kjl;kjlk;jlk;', 'jlkjl;k', 38),
(72, 'jkljkljl;j', 3, 'jl;jlk;j', 'l;kjl;kjlk;jlk;', 'jlkjl;k', 39),
(73, 'jkljkljl;j', 3, 'jl;jlk;j', 'l;kjl;kjlk;jlk;', 'jlkjl;k', 40),
(74, 'jkljkljl;j', 3, 'jl;jlk;j', 'l;kjl;kjlk;jlk;', 'jlkjl;k', 41),
(75, 'jkljkljl;j', 3, 'jl;jlk;j', 'l;kjl;kjlk;jlk;', 'jlkjl;k', 42),
(76, 'jkljkljl;j', 3, 'jl;jlk;j', 'l;kjl;kjlk;jlk;', 'jlkjl;k', 45),
(77, 'yuyiy', 12, 'iuyiuyi', 'yuiyiyy', 'uiyi', 0),
(78, 'yuyiy', 12, 'iuyiuyi', 'yuiyiyy', 'uiyi', 1),
(79, 'yuyiy', 12, 'iuyiuyi', 'yuiyiyy', 'uiyi', 2),
(80, 'yuyiy', 12, 'iuyiuyi', 'yuiyiyy', 'uiyi', 3),
(81, 'yuyiy', 12, 'iuyiuyi', 'yuiyiyy', 'uiyi', 4),
(82, 'yuyiy', 12, 'iuyiuyi', 'yuiyiyy', 'uiyi', 5),
(83, 'yuyiy', 12, 'iuyiuyi', 'yuiyiyy', 'uiyi', 6),
(84, 'yuyiy', 12, 'iuyiuyi', 'yuiyiyy', 'uiyi', 7),
(85, 'Hi', 13, 'world', 'food', '9890', 7),
(86, 'Hi', 13, 'world', 'food', '9890', 0),
(87, 'Hi', 13, 'world', 'food', '9890', 39),
(88, 'hjkhkjhjk', 17, 'hlkhljhljk', 'hjklhlkjhjkl', 'hjlkhjkl', 0),
(89, 'hjkhjkhkjhk', 17, 'hkhjkh', 'klhjklh', 'kjlhjkl', 0),
(90, '', 17, '', '', '', 0),
(91, '', 17, '', '', '', 0),
(92, '', 17, '', '', '', 0),
(93, 'g', 17, 'g', 'g', 'g', 0),
(94, '', 17, '', '', '', 0),
(95, '', 17, '', '', '', 0),
(96, '', 17, '', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `reviews` varchar(255) NOT NULL,
  `id` bigint(20) UNSIGNED NOT NULL,
  `restaurant_id` varchar(255) NOT NULL,
  `author` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`reviews`, `id`, `restaurant_id`, `author`) VALUES
('it sucked', 1, '7', 'andrew'),
('it sucked', 2, '7', 'andrew'),
('it sucked', 3, '7', 'andrew'),
('it sucked', 4, '7', 'andrew'),
('it was awful my waitor was a bitch', 5, '7', 'me'),
('it was awful my waitor was a bitch', 6, '7', 'me'),
('it was awful my waitor was a bitch', 7, '7', 'me'),
('it was awful my waitor was a bitch', 8, '7', 'me'),
('jkljlkjjklj', 9, '7', 'jkljklj'),
('hjhjj jkhjkhkjhkjh', 10, '7', 'hjhkjhkjhjk'),
('"fafA"FAffa', 11, '7', 'S"SfsFSF"'),
('<hello>', 12, '7', 'faf'),
('<hello>', 13, '7', 'faf'),
('<hello>', 14, '7', 'faf'),
('<hello>', 15, '7', 'faf'),
('hjkhkjhkjl', 16, '24', 'sally'),
('hjkljkljlk', 17, '12', 'chris'),
('it sucked', 18, '25', 'jesse'),
('awesome food', 19, '26', 'jesse'),
('it had kfraft mexican blend cheese all over it', 20, '25', 'jesse'),
('it sucked', 21, '21', 'jesse');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cuisine`
--
ALTER TABLE `cuisine`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `restaurants`
--
ALTER TABLE `restaurants`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cuisine`
--
ALTER TABLE `cuisine`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
--
-- AUTO_INCREMENT for table `restaurants`
--
ALTER TABLE `restaurants`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=97;
--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
